import { Component } from '@angular/core';

@Component({
  selector: 'swa-calendar-app',
  template: `
		<div class="parent">
            <h1>Hello {{name}}</h1>
            
        </div>
  `
})
export class AppComponent { 

	name = 'Angular';
	id = 'Sridhar1234';

 }

